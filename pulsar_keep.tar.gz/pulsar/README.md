# SQLStream Pulsar Plugin
Apache Pulsar is an open-source distributed messaging system. Key features of Pulsar are listed below:
  - Native support for multiple clusters in a Pulsar instance, with seamless geo-replication of messages across clusters.
  - Very low publish and end-to-end latency.
  - Guaranteed message delivery with persistent message storage provided by Apache BookKeeper.
  - Tiered Storage offloads data from hot/warm storage to cold/longterm storage (such as S3 and GCS) when the data is aging out.

### SQLStream Pulsar Output Sink
Currently SQLStream `Pulsar Plugin` supports the following features:
  - TLS Encryption and Authentication for connection between producer and broker.
  - Async send with configurable batching and queue size.
  - Compression are supported and configurable.
  - Routing Mode are configurable: RoundRobinPartition, SinglePartition and CustomPartition.
  - PULSAR_TIMESTAMP column to specify the event time.
  - Properties file to specify the Pulsar configurations.
 
There are many more configurations supported by the plugin that are present in Apache Pulsar but they are not in our current scope.

**Future Scope**:
  - Pulsar Input Stream.

### Install Pulsar Plugin
Follow the below given steps to install the sqlstream pulsar plugin:

**STEP1:** Within the directory `pulsar/`, create the tar file of the plugin by the name `pulsar.tar.gz` which contains the `pulsar.jar`, `lib/` and `install.sql` file, using the `makeTarball.sh` script as follows:
```sh
$ ./makeTarball.sh .
```

**STEP2:** Copy the `pulsar.tar.gz` file in the following directory on sqlstream server and extract it:
```
/opt/sqlstream/<sqlstream-version>/s-Server/plugin/
$ tar xzvf pulsar.tar.gz
```
A `pulsar/` directory will be created with the following structure:
```
drwxrwxr-x  3 sqlstream sqlstream  4096 Jun 17 11:54 ./
drwxr-xr-x 26 sqlstream sqlstream  4096 Jun 17 11:24 ../
-rw-rw-r--  1 sqlstream sqlstream   234 Jun 15 09:23 install.sql
drwxrwxr-x  2 sqlstream sqlstream  4096 Jun 15 09:20 lib/
-rw-r--r--  1 sqlstream sqlstream 12952 Jun 18 11:00 pulsar.jar
```
**STEP3:** Add the following line to the `install.sql` script present in the `pulsar/` directory:
```
CREATE OR REPLACE SERVER PULSAR_SERVER type 'PULSAR' foreign data wrapper ECDA;
```

**STEP4:** Run the `install.sql` script to create the `PULSAR_SERVER` sink.
```sh
$ /opt/sqlstream/<sqlstream-version>/s-Server/bin/sqllineClient --run=pulsar/install.sql
```

### Install Apache Pulsar Standalone
**Pre-requisite-** Java 8

Download the Pulsar Binary:
```sh
$ wget https://archive.apache.org/dist/pulsar/pulsar-2.5.2/apache-pulsar-2.5.2-bin.tar.gz
```
Extract the pulsar executables:
```sh
$ tar xvfz apache-pulsar-2.5.2-bin.tar.gz
$ cd apache-pulsar-2.5.2
```
Run the standalone:
```sh
$ bin/pulsar standalone
```

### SQLStream Configurations:
To enable various pulsar configurations, add the configs in the `pulsar.properties` file and provide the absolute path to the properties file in the sql file as `pulsarConfigFile` property. All the SQLStream properties have same name as mentioned in the official pulsar documentation. See the following page for different pulsar and sqlstream configurations: https://guavus.atlassian.net/wiki/spaces/MIQ/pages/1336967206/SQLStream+Pulsar+Plugin

Sample SQL file and data file are present in the `test/` directory.

