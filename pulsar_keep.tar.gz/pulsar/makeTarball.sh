#!/bin/sh
# builds plugin tarball
cd `dirname $0`
if [ ! -d $1/src ]; then
    echo Usage: $0 \<adapter dir\>
    exit 1
fi
name=`basename $1`
mkdir tmp
cd $name
mvn package
jarName=`basename target/*.jar |sed -e 's/-[0-9].*\.jar/.jar/'`
echo "CREATE OR REPLACE JAR sys_boot.sys_boot.$name LIBRARY 'file:plugin/$name/$jarName' OPTIONS(0);" > target/install.sql
if grep -q '<plugin.factory>' pom.xml; then
    echo "alter system add catalog jar sys_boot.sys_boot.$name;" >>target/install.sql
fi
tar -czf ../$name.tar.gz --transform "s/^target/$name/" --transform 's/-[0-9].*\.jar/.jar/' target/*.jar target/install.sql 
tar zxvf ../$name.tar.gz -C ../tmp/
if [ -d target/lib ]; then
    cp -R target/lib ../tmp/$name/
fi
cd ../tmp
tar -czf ../$name.tar.gz ./$name
rm -rf ../tmp/
