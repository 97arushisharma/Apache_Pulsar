package com.sqlstream.aspen.namespace.pulsar;

import java.util.TimerTask;

public class CountScheduler extends TimerTask {

        private PulsarOutputSink pos = new PulsarOutputSink();

	private boolean hasStarted = false;

        public void run() {
	    this.hasStarted = true;
            pos.printCount();
        }


	public boolean cancelTask(){
	    this.hasStarted = false;
	    return this.cancel();
	}

	public Boolean hasRunStarted(){
	    return this.hasStarted;
	}
}
