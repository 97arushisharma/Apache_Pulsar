/*
// $Id: //depot/release/6.0.x/aspen/adapters/kafka/src/main/java/com/sqlstream/aspen/namespace/kafka/PluginFactory.java#1 $
// Aspen dataflow server
// Copyright (C) 2015-2015 SQLstream, Inc.
*/
package com.sqlstream.aspen.namespace.pulsar;

import com.sqlstream.aspen.namespace.common.EcdaPluginFactory;

import java.io.File;
import java.util.logging.LogManager;

public class PluginFactory
    extends EcdaPluginFactory
{
    public void installPlugins()
    {
        if (System.getProperty("pulsar.logs.dir") == null) {
            // so log4j is configured right.
            LogManager logManager = LogManager.getLogManager();
            String fileHandlePattern = logManager.getProperty("java.util.logging.FileHandler.pattern");
            if (fileHandlePattern != null) {
                String logDir = (new File(fileHandlePattern)).getParent();
                System.setProperty("pulsar.logs.dir", logDir);
            }
        }
        //installSource("kafka", PulsarInputSource.class);
        installSink("pulsar", PulsarOutputSink.class);
    }
}
// End PluginFactory.java
