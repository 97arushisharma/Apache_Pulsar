package com.sqlstream.aspen.namespace.pulsar;

import org.apache.pulsar.client.api.PulsarClient;
import org.apache.pulsar.client.api.PulsarClientException;

import java.util.Map;

public class PulsarClientFactory {

    public PulsarClient getClient(Map<String, Object> configClient) throws PulsarClientException {
        return PulsarClient.builder()
                .loadConf(configClient)
                .build();
    }

}
