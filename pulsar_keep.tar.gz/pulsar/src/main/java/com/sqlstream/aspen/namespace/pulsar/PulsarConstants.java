package com.sqlstream.aspen.namespace.pulsar;

public final class PulsarConstants {

    public static final String CUSTOM_PARTITION = "CustomPartition";
    public static final String ROUND_ROBIN_PARTITION = "RoundRobinPartition";
    public final static String [] clientConfs = {
            "operationTimeoutMs",
            "connectionsPerBroker",
            "authPluginClassName",
            "connectionTimeoutMs",
            "tlsHostnameVerificationEnable",
            "authParams",
            "numListenerThreads",
            "maxLookupRequest",
            "keepAliveIntervalSeconds",
            "tlsTrustCertsFilePath",
            "useTls",
            "initialBackoffIntervalNanos",
            "requestTimeoutMs",
            "serviceUrl",
            "statsIntervalSeconds",
            "numIoThreads",
            "concurrentLookupRequest",
            "useTcpNoDelay",
            "maxNumberOfRejectedRequestPerConnection",
            "maxBackoffIntervalNanos",
            "tlsAllowInsecureConnection"
    };
    public final static String [] producerConfs = {
            "topicName",
            "producerName",
            "sendTimeoutMs",
            "blockIfQueueFull",
            "maxPendingMessages",
            "maxPendingMessagesAcrossPartitions",
            "messageRoutingMode",
            "hashingScheme",
            "cryptoFailureAction",
            "batchingMaxPublishDelayMicros",
            "batchingMaxMessages",
            "batchingEnabled",
            "compressionType"
    };

    public final static String [] requiredParameters = {
            "topicName" // persistent://my-tenant/my-namespace/${record:value("/my-topic")}
    };

    public final static String [] optionalParameters = {
            //"topicNamespace", //user-defined. Default persistent://public/default/
            "serviceUrl", //http://<host name>:<web service port> OR pulsar://<host name>:<broker service port>
            "useTls", //True to enable or false to disable. If enabled the pulsar.url as pulsar+ssl://<host name>:<broker service TLS port>
            "tlsTrustCertsFilePath",
            "messageRoutingMode", //routing modes -  SinglePartition or RoundRobinPartition. Default pulsar.RoundRobinDistribution.
            "sendTimeoutMs", //If a message is not acknowledged by a server before the sendTimeout expires, an error occurs.
            "keepAliveIntervalSeconds", //Default 30000. Number of milliseconds to allow the connection to Pulsar to remain idle. After the destination publishes no messages for this amount of time, the connection is closed. The destination must reconnect to Pulsar.
            "connectionTimeoutMs", // Default 10000 Duration of waiting for a connection to a broker to be established. If the duration passes without a response from a broker, the connection attempt is dropped
            "sendAsync", // ******* Default enabled. True to async.
            "blockIfQueueFull", //If it is set to true, when the outgoing message queue is full, the Send and SendAsync methods of producer block, rather than failing and throwing errors.
            "compressionType", //Type of compression to apply to the published messages: None, LZ4,ZLIB, ZSTD,SNAPPY. Default None.
            "maxPendingMessages", //Default 1000 When sending messages asynchronously, the maximum number of messages that can wait in the queue for an acknowledgement from the Pulsar broker.
            "maxPendingMessagesAcrossPartitions", //Default 50000. The maximum number of pending messages across partitions.
            "batchingEnabled", // Default enabled. When sending messages asynchronously, enables sending a batch of messages in a single request. Clear to send a single message in each request. Default is enabled.
            "batchingMaxMessages", // Default 1000. The maximum number of messages permitted in a batch.
            "batchingMaxPublishDelayMicros", // Batching time period of sending messages. TimeUnit.MILLISECONDS.toMicros(1)
            "cryptoFailureAction", //Default ProducerCryptoFailureAction.FAIL. Producer should take action when encryption fails. FAIL: if encryption fails, unencrypted messages fail to send.SEND: if encryption fails, unencrypted messages are sent.
            "producerName", //Name of the producer
            "hashingScheme",
            "operationTimeoutMs",
            "connectionsPerBroker",
            "authPluginClassName",
            "tlsHostnameVerificationEnable",
            "authParams",
            "numListenerThreads",
            "maxLookupRequest",
            "initialBackoffIntervalNanos",
            "requestTimeoutMs",
            "statsIntervalSeconds",
            "numIoThreads",
            "concurrentLookupRequest",
            "useTcpNoDelay",
            "maxNumberOfRejectedRequestPerConnection",
            "maxBackoffIntervalNanos",
            "tlsAllowInsecureConnection",
            "COUNT_SCHEDULER_TIME",
            "PULSAR_CONFIG_FILE",
            "publicKeyFile",
            "privateKeyFile",
            "encryptionKey",
            "messageEncryption"
    };
}