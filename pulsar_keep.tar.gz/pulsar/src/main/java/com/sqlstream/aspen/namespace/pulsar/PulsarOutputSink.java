/*
// $Id: //depot/release/6.0.x/aspen/adapters/pulsar/src/main/java/com/sqlstream/aspen/namespace/pulsar/PulsarOutputSink.java#2 $
// Aspen dataflow server
// Copyright (C) 2014-2014 SQLstream, Inc.
*/

package com.sqlstream.aspen.namespace.pulsar;

import com.sqlstream.aspen.namespace.common.*;
import com.sqlstream.aspen.core.RuntimeObjectContext;
import net.sf.farrago.jdbc.ExtendedResultSet;
import org.apache.pulsar.client.api.*;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.sqlstream.aspen.namespace.pulsar.PulsarConstants.*;

/**
 *
 * @author  arushi.sharma
 * @version $Id: //depot/release/6.0.x/aspen/adapters/pulsar/src/main/java/com/sqlstream/aspen/namespace/pulsar/PulsarOutputSink.java#2 $
 **/
public class PulsarOutputSink implements DataOutputRowSink, MessageRouter, CryptoKeyReader
{
    protected static final Logger tracer =
        Logger.getLogger("com.sqlstream.aspen.namespace.pulsar");

    final protected Properties initProps = new Properties();

    private long messageTimestamp;
    private int pulsarPartition = -1;
    private int partitionColumnIndex = -1;
    private int eventTimeColumnIndex = -1;
    private int keyColumnIndex = -1;

    protected static Timer time = new Timer(); // Instantiate Timer Object
    protected static CountScheduler cs = new CountScheduler();
    private static AtomicInteger count = new AtomicInteger();
    
    private Map<String, Object> configClient = new HashMap<>();
    private Map<String, Object> configProducer = new HashMap<>();
    private Map<String, Object> config = new HashMap<>();

    private String topic;
    private Boolean asyncSend;
    private Boolean messageEncryption;
    protected String publicKeyFile = null;
    protected String privateKeyFile = null;

    protected Producer<byte[]> producer;
    protected Connection queryConnection = null;
    protected EcdaWriterContext context;
    protected PulsarProducerFactory producerFactory = new PulsarProducerFactory();
    protected PulsarClientFactory clientFactory =  new PulsarClientFactory();



    public PulsarOutputSink()
    {
    }

    public void setContext(EcdaWriterContext context) {
        this.context = context;
    }

    private static void setPropsIfNotExists(Map<String, Object> props, String key, Object value)
    {
        Object prop = props.get(key);
        if (prop == null || prop.toString().trim().isEmpty()) {
            props.put(key,value);
        }
    }

    private static boolean contains(String[] arr, String targetValue) {
        for(String s: arr){
            if(s.equals(targetValue))
                return true;
        }
        return false;
    }


    public static void printCount() {
        tracer.log(Level.INFO, "Total acknowledged records: "+ count.get());
    }

    // Custom Partitioner Functions
    // returns the partition value supplied by the PULSAR_PARTITION column

    public int choosePartition(Message<?> msg, TopicMetadata metadata){
        if(metadata.numPartitions() <= pulsarPartition)
            throw new RuntimeException("Partition "+ pulsarPartition +" is invalid. Number of partitions should not be more than "+ metadata.numPartitions()+".");
  		if(pulsarPartition == -1)
  			throw new RuntimeException("Partition value NULL is invalid. Partition value cannot be NULL.");

        return pulsarPartition;
    }

    // Functions implementations for CryptoKeyReader class
    @Override
    public EncryptionKeyInfo getPublicKey(String keyName, Map<String, String> keyMeta) {
        EncryptionKeyInfo keyInfo = new EncryptionKeyInfo();
        try {
            if(publicKeyFile != "" && publicKeyFile != null){
                keyInfo.setKey(Files.readAllBytes(Paths.get(publicKeyFile)));
                if(tracer.isLoggable(Level.CONFIG)){
                	tracer.log(Level.INFO, "Sending encrypted messages... ");
                }
            }
        } catch (IOException e) {
            tracer.log(Level.WARNING,"ERROR: Failed to read public key from file " + publicKeyFile);
            e.printStackTrace();
        }
        return keyInfo;
    }

    @Override
    public EncryptionKeyInfo getPrivateKey(String keyName, Map<String, String> keyMeta) {
        EncryptionKeyInfo keyInfo = new EncryptionKeyInfo();
        try {
            if(privateKeyFile != "" && privateKeyFile != null)
                keyInfo.setKey(Files.readAllBytes(Paths.get(privateKeyFile)));
        } catch (IOException e) {
            tracer.log(Level.WARNING,"ERROR: Failed to read private key from file " + privateKeyFile);
            e.printStackTrace();
        }
        return keyInfo;
    }


    public void init(Properties props) throws Exception
    {

            // Read configurations from config file
            try {
                //tracer.log(Level.INFO, "Configs file path: " + props.getProperty("PULSAR_CONFIG_FILE") + " Phase: "+ context.getPhase());
                FileReader reader = new FileReader(props.getProperty("PULSAR_CONFIG_FILE"));
                props.load(reader);
                reader.close();
            } catch (NullPointerException e){
                tracer.log(Level.WARNING, "Pulsar Configuration missing: "+ e + "\n");
            } catch (Exception e){
                tracer.log(Level.WARNING, "Error occurred while reading the config file: " + e );
            }

            OptionsUtils.filterInitProperties(
                props, requiredParameters, optionalParameters, initProps);

            Properties dynamicProps = OptionsUtils.addDynamicOptions(
            	initProps, queryConnection);

        	// Separate Client and Producer configuarations
        	for (String propName : dynamicProps.stringPropertyNames()) {
            	if(contains(clientConfs,propName)){
                	configClient.put(propName, dynamicProps.getProperty(propName));
            	} else if (contains(producerConfs,propName)){
                	configProducer.put(propName, dynamicProps.getProperty(propName));
            	} else {
                	config.put(propName, dynamicProps.getProperty(propName));
            	}
        	}

        String urlVal = "pulsar://127.0.0.1:6650";
	
        if(dynamicProps.containsKey("useTls") && Boolean.parseBoolean(dynamicProps.getProperty("useTls"))){
        	urlVal = "pulsar+ssl://127.0.0.1:6651";
        }

        setPropsIfNotExists(
                configClient,
                "serviceUrl",
                urlVal);
        
        setPropsIfNotExists(
                configProducer,
                "producerName",
                "SQLStreamProducer");
        setPropsIfNotExists(
                config,
                "sendAsync",
                true);
        setPropsIfNotExists(
                config,
                "COUNT_SCHEDULER_TIME",
                0);
        setPropsIfNotExists(
                config,
                "encryptionKey",
                "sqlstream.key");
        setPropsIfNotExists(
                config,
                "messageEncryption",
                false);

        topic = dynamicProps.getProperty("topicName");
        asyncSend = Boolean.parseBoolean(config.get("sendAsync").toString());
        publicKeyFile = dynamicProps.getProperty("publicKeyFile");
        privateKeyFile = dynamicProps.getProperty("privateKeyFile");
        messageEncryption = Boolean.parseBoolean(config.get("messageEncryption").toString());

    }

    public Properties getInitProperties()
    {
        return initProps;
    }


    public void open() throws Exception
    {
        if (null == producer) {

	    if (tracer.isLoggable(Level.CONFIG)) {
                tracer.log(Level.INFO, "Topic: " + topic + "  Client Configurations: " + configClient.toString() + "  Producer Configurations: " + configProducer.toString() + "  Custom Configurations: " + config.toString());
        }
	    

	    try {
            keyColumnIndex  = context.getResultSet().findColumn("PULSAR_KEY");
            if(keyColumnIndex > 0 && context.getResultSet().getMetaData().getColumnType(keyColumnIndex) != Types.VARBINARY){
            	keyColumnIndex = -1;
            	tracer.log(Level.WARNING, "Data Type mismatch. Expected a VARBINARY type value for PULSAR_KEY column.");
            }
        } catch (SQLException se) {
        }

        try {
            eventTimeColumnIndex  = context.getResultSet().findColumn("PULSAR_TIMESTAMP");
            if(eventTimeColumnIndex > 0 && context.getResultSet().getMetaData().getColumnType(eventTimeColumnIndex) != Types.TIMESTAMP){
            	eventTimeColumnIndex = -1;
            	tracer.log(Level.WARNING, "Data Type mismatch. Expected a TIMESTAMP type value for PULSAR_TIMESTAMP column.");
            }
        } catch (SQLException se) {
        }

        try {
            partitionColumnIndex  = context.getResultSet().findColumn("PULSAR_PARTITION");
            if(partitionColumnIndex > 0 && context.getResultSet().getMetaData().getColumnType(partitionColumnIndex) != Types.INTEGER){
            	partitionColumnIndex = -1;
            	tracer.log(Level.WARNING, "Data Type mismatch. Expected an INTEGER type value for PULSAR_PARTITION column.");
            }
        } catch (SQLException se) {
        }

        	// Pulsar Client and Producer object declaration
            PulsarClient client = clientFactory.getClient(configClient);

            String encryptionKey = config.get("encryptionKey").toString();

            if((partitionColumnIndex == -1 || partitionColumnIndex == 0) && configProducer.get("messageRoutingMode") != null && configProducer.get("messageRoutingMode").toString().equals(CUSTOM_PARTITION))
                configProducer.put("messageRoutingMode", ROUND_ROBIN_PARTITION);

            if(messageEncryption == false){
            	publicKeyFile = null;
            	privateKeyFile = null;
            } else if(publicKeyFile == null){
            	throw new IllegalArgumentException("No publicKeyFile supplied for message encryption. Either disable messageEncryption or supply a publicKeyFile.");
            }

            if(publicKeyFile != null){

                if(partitionColumnIndex > 0 && configProducer.get("messageRoutingMode") != null && configProducer.get("messageRoutingMode").toString().equals(CUSTOM_PARTITION)){
                    producer = producerFactory.getProducer(client,configProducer,this,topic,encryptionKey,this);
                } else {
                    producer = producerFactory.getProducer(client,configProducer,topic,encryptionKey,this);
                }

            } else {

                if(partitionColumnIndex > 0 && configProducer.get("messageRoutingMode") != null && configProducer.get("messageRoutingMode").toString().equals(CUSTOM_PARTITION)){
                    producer = producerFactory.getProducer(client,configProducer,this,topic);
                } else {
                    producer = producerFactory.getProducer(client,configProducer,topic);
                }

            }

        // Scheduling a counter for acknowledged messages
        long schedulerTime = Long.parseLong(config.get("COUNT_SCHEDULER_TIME").toString());
        if(!(cs.hasRunStarted()) && schedulerTime !=0){
            cs = new CountScheduler();
            time.schedule(cs, 0, schedulerTime); // Create Repetitively task for every schedulerTime milli secs
        }
        } 

        context.notifyOnCancel(() -> Thread.currentThread().interrupt());
    }

    public TypeFormatter specialFormatterFor(String fieldName, int fieldType, int colIdx)
    {
        if (fieldName.equals("PULSAR_KEY") || fieldName.equals("PULSAR_PARTITION")
                || fieldName.equals("PULSAR_TIMESTAMP"))
        {
            return new TypeFormatter() {
                public void init(Properties props)
                        throws Exception
                {
                    // do nothing
                }
                @Override
                public void setContext(RuntimeObjectContext context)
                {
                    // do nothing
                }
                @Override
                public Properties getInitProperties()
                {
                    return null;
                }
                @Override
                public void closeAllocation()
                {
                    // do nothing
                }
                @Override
                public void format(ResultSet rs)
                        throws SQLException
                {
                    // do nothing
                }
            };
        }
        return null;
    }

    public void write(byte[] buf, int start, int end) throws Exception {

        try {
            if (start == end) {
                return;
            }

            open();

            final byte [] message;
            if (0 == start && buf.length == end) {
                message = buf;
            } else {
                byte[] partialBuffer = new byte[end - start];
                System.arraycopy(buf, start, partialBuffer, 0, end - start);
                message = partialBuffer;
            }



            byte[] keyBytes = null;
            if (keyColumnIndex > 0) {
                keyBytes = context.getResultSet().getBytes(keyColumnIndex);
                if (context.getResultSet().wasNull()) {
                    keyBytes = null;
                }
            }

            long eventTime = messageTimestamp;
            if (eventTimeColumnIndex > 0) {
                ExtendedResultSet ers = (ExtendedResultSet) context.getResultSet();
                eventTime = ers.getNormalizedLong(eventTimeColumnIndex);
                if (context.getResultSet().wasNull()) {
                    tracer.warning("The value for non-nullable field EventTime is null. Discarding the row...");
                    return;
                }
            }

            if (partitionColumnIndex > 0) {
                pulsarPartition = context.getResultSet().getInt(partitionColumnIndex);
                if (context.getResultSet().wasNull()) {
                    pulsarPartition = -1;
                }
            }

            // Send message
            try{
            	if(keyBytes != null && keyBytes.length > 0){
                	if(asyncSend) {
	                    //producer.sendAsync(message);
	                    CompletableFuture<MessageId> future = producer.newMessage().value(message).keyBytes(keyBytes).eventTime(eventTime).sendAsync();
	                    future.thenAccept(msgId -> {
	                        count.incrementAndGet();
	                    }).exceptionally(e -> {
                            tracer.log(Level.WARNING, "Error while sending the message: "+e);
                            return null;
                        });
	                } else {
	                    //producer.send(msg);
	                    MessageId msgId = producer.newMessage().value(message).keyBytes(keyBytes).eventTime(eventTime).send();
	                    count.incrementAndGet();
	                }
	            } else {
		            if(asyncSend) {
		                //producer.sendAsync(message);
		                CompletableFuture<MessageId> future = producer.newMessage().value(message).eventTime(eventTime).sendAsync();
		                future.thenAccept(msgId -> {
		                    count.incrementAndGet();
		                }).exceptionally(e -> {
                            tracer.log(Level.WARNING, "Error while sending the message: "+e);
                            return null;
                        });
	                } else {
	                    //producer.send(msg);
	                    MessageId msgId = producer.newMessage().value(message).eventTime(eventTime).send();
	                    count.incrementAndGet();
	                }
	            }
            } catch (PulsarClientException.ProducerQueueIsFullError e){
            	tracer.log(Level.WARNING, "maxPendingMessages queue size exceeded. Dropping.....");
            }
	        


            if (tracer.isLoggable(Level.FINE)) {
                tracer.fine("writing " + (end - start) + " bytes");
            }
        } catch (Throwable e) {
            tracer.log(Level.WARNING, "Error writing to pulsar topic - " + topic, e);
        }
    }



    public void writeBounds(long bounds) throws Exception
    {
    	messageTimestamp = bounds;
    }

    public void flush() throws Exception
    {
    	if (producer != null) {
            producer.flush();
        }
    }

    public void close() throws Exception
    {
        flush();
        // Assigning 0 to count
        count.set(0);
        // Stopping the count scheduler if started
        if(cs.hasRunStarted()){
            cs.cancelTask();
        }
        if (producer != null) {
            producer.close();
        }
    }

    public void closeAllocation()
    {
        try {
	    
            close();
        } catch (Exception e) {
            tracer.log(Level.CONFIG, e.getMessage(), e);
        }
    }

    public void setQueryConnection(java.sql.Connection conn)
    {
        this.queryConnection = conn;
    }

    public static AtomicInteger getCount() {
        return count;
    }

}

// End PulsarOutputSink.java
