package com.sqlstream.aspen.namespace.pulsar;

import org.apache.pulsar.client.api.*;

import java.util.Map;

public class PulsarProducerFactory {

    public Producer getProducer(PulsarClient client , Map<String, Object> configProducer, MessageRouter messageRouter , String topic, String encryptionKey, CryptoKeyReader cryptoKeyReader) throws PulsarClientException {
        return client.newProducer()
                .loadConf(configProducer)
                .messageRouter(messageRouter)
                .topic(topic)
                .addEncryptionKey(encryptionKey)
                .cryptoKeyReader(cryptoKeyReader)
                .create();

    }

    public Producer getProducer(PulsarClient client , Map<String, Object> configProducer, String topic , String encryptionKey , CryptoKeyReader cryptoKeyReader) throws PulsarClientException{
        return client.newProducer()
                .loadConf(configProducer)
                .topic(topic)
                .addEncryptionKey(encryptionKey)
                .cryptoKeyReader(cryptoKeyReader)
                .create();
    }

    public Producer getProducer(PulsarClient client , Map<String, Object> configProducer , MessageRouter messageRouter , String topic) throws PulsarClientException{
        return client.newProducer()
                .loadConf(configProducer)
                .messageRouter(messageRouter)
                .topic(topic)
                .create();
    }

    public Producer getProducer(PulsarClient client , Map<String, Object> configProducer , String topic) throws PulsarClientException{
        return client.newProducer()
                .loadConf(configProducer)
                .topic(topic)
                .create();
    }




}
