package com.sqlstream.aspen.namespace.pulsar.test;

import com.sqlstream.aspen.namespace.pulsar.PluginFactory;
import org.junit.Test;

public class PluginFactoryTest {
    @Test
    public void test() {
        PluginFactory pluginFactory = new PluginFactory();
        pluginFactory.installPlugins();
    }


}
