package com.sqlstream.aspen.namespace.pulsar.test;

import com.sqlstream.aspen.namespace.common.EcdaWriterContext;
import com.sqlstream.aspen.namespace.common.TypeFormatter;
import com.sqlstream.aspen.namespace.pulsar.PulsarClientFactory;
import com.sqlstream.aspen.namespace.pulsar.PulsarOutputSink;
import com.sqlstream.aspen.namespace.pulsar.PulsarProducerFactory;
import net.sf.farrago.jdbc.ExtendedResultSet;
import org.apache.pulsar.client.api.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;

import static com.sqlstream.aspen.namespace.pulsar.PulsarConstants.CUSTOM_PARTITION;
import static org.junit.Assert.*;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.*;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.when;

public class PulsarOutputSinkTest {

    @Mock(answer = Answers.RETURNS_MOCKS)
    EcdaWriterContext context;

    @Mock
    ResultSet resultSet;

    @InjectMocks
    PulsarOutputSink pulsarOutputSink = new PulsarOutputSink();

    @Mock
    TopicMetadata topicMetadata;

    @Mock
    Message message;

    @Mock
    PulsarProducerFactory producerFactory;

    @Mock
    PulsarClientFactory clientFactory;

    @Mock
    Producer producer;

    @Mock
    PulsarClient client;

    @Mock
    TypedMessageBuilder newMessageBuilder;

    @Mock
    CompletableFuture completableFuture;

    @Mock
    ResultSetMetaData resultSetMetaData;

    @Mock
    MessageId messageId;

    @Mock
    ExtendedResultSet extendedResultSet;

    Properties properties;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        pulsarOutputSink.setContext(context);

        properties = new Properties();
        properties.put("topicName", "pulsar-test");
        properties.put("producerName", "pulsar-test-producer");
        properties.put("PULSAR_CONFIG_FILE", "src/test/resources/pulsarTest.properties");

        HashMap configClient = new HashMap<>();
        HashMap configProducer = new HashMap<>();
        when(context.getResultSet()).thenReturn(resultSet);
        when(clientFactory.getClient(configClient)).thenReturn(client);
        when(producerFactory.getProducer(eq(client), eq(configProducer), eq(pulsarOutputSink), anyString(), anyString(), eq(pulsarOutputSink))).thenReturn(producer);
        when(producerFactory.getProducer(eq(client), eq(configProducer), anyString(), anyString(), eq(pulsarOutputSink))).thenReturn(producer);
        when(producerFactory.getProducer(eq(client), eq(configProducer), eq(pulsarOutputSink), anyString())).thenReturn(producer);
        when(producerFactory.getProducer(eq(client), eq(configProducer), anyString())).thenReturn(producer);

        // data mismatch block coverage
        when(resultSet.findColumn("PULSAR_KEY")).thenReturn(1);
        when(resultSet.findColumn("PULSAR_TIMESTAMP")).thenReturn(1);
        when(resultSet.findColumn("PULSAR_PARTITION")).thenReturn(1);

        when(resultSet.getMetaData()).thenReturn(resultSetMetaData);
        when(resultSetMetaData.getColumnType(anyInt())).thenReturn(1);

        try {
            pulsarOutputSink.init(properties);
        } catch (Exception e) {
            fail("Property initialisation failed");
        }

    }

    @Test
    public void testInit() {
        try {
            pulsarOutputSink.init(properties);
            final Class pulsarOutputSinkclass = Class.forName("com.sqlstream.aspen.namespace.pulsar.PulsarOutputSink");
            Field topic = pulsarOutputSinkclass.getDeclaredField("topic");
            Field asyncSend = pulsarOutputSinkclass.getDeclaredField("asyncSend");
            Field messageEncryption = pulsarOutputSinkclass.getDeclaredField("messageEncryption");
            messageEncryption.setAccessible(true);
            asyncSend.setAccessible(true);
            topic.setAccessible(true);
            assertTrue(topic.get(pulsarOutputSink).equals("pulsar-test") && messageEncryption.getBoolean(pulsarOutputSink) == false && asyncSend.getBoolean(pulsarOutputSink) == true);
        } catch (Exception ex) {
        }


    }

    @Test(expected = RuntimeException.class)
    public void testChoosePartition_invalid_PartitionVal() {
        when(topicMetadata.numPartitions()).thenReturn(1);
        pulsarOutputSink.choosePartition(message, topicMetadata);
    }

    @Test(expected = RuntimeException.class)
    public void testChoosePartition_NULL_PartitionVal() {
        when(topicMetadata.numPartitions()).thenReturn(-2);
        pulsarOutputSink.choosePartition(message, topicMetadata);
    }

    @Test
    public void testChoosePartition_correct_partitionVal() {
        try {
            final Class pulsarOutputSinkclass = Class.forName("com.sqlstream.aspen.namespace.pulsar.PulsarOutputSink");
            Field pulsarPartition = pulsarOutputSinkclass.getDeclaredField("pulsarPartition");
            pulsarPartition.setAccessible(true);
            pulsarPartition.set(pulsarOutputSink, 1);
            when(topicMetadata.numPartitions()).thenReturn(2);
            assertEquals(1, pulsarOutputSink.choosePartition(message, topicMetadata));
        } catch (Exception ex) {
            fail("Exception in testChoosePartition_3");
        }
    }

    @Test
    public void testCloseAllocation() {
        try {
            pulsarOutputSink.closeAllocation();
            assertEquals(0, PulsarOutputSink.getCount().get());
        } catch (Exception e) {
            fail("Closing connection failed");
        }
    }

    @Test
    public void testPrintCount() {
        try {
            PulsarOutputSink.printCount();
            assertEquals(0, PulsarOutputSink.getCount().get());
        } catch (Exception ex) {
            fail("print count failed");
        }
    }

    @Test
    public void testSpecialFormatterFor() {
        try {
            assertTrue(pulsarOutputSink.specialFormatterFor("PULSAR_KEY", 1, 1) instanceof TypeFormatter);
            assertTrue(pulsarOutputSink.specialFormatterFor("PULSAR_PARTITION", 1, 1) instanceof TypeFormatter);
            assertTrue(pulsarOutputSink.specialFormatterFor("PULSAR_TIMESTAMP", 1, 1) instanceof TypeFormatter);
        } catch (Exception ex) {
            fail();
        }
    }

    @Test
    public void testSpecialFormatterFor_IncorrectFieldName() {
        assertNull(pulsarOutputSink.specialFormatterFor("TEST_KEY", 1, 1));
    }

    @Test
    public void testGetPublicKey() {
        try {
            EncryptionKeyInfo keyInfo = pulsarOutputSink.getPublicKey("test", new HashMap<>());
            assertTrue(keyInfo.getKey() == null);
        } catch (Exception ex) {
            fail();
        }
    }

    @Test
    public void testGetPrivateKey() {
        try {
            EncryptionKeyInfo keyInfo = pulsarOutputSink.getPrivateKey("test", new HashMap<>());
            assertTrue(keyInfo.getKey() == null);
        } catch (Exception ex) {
            fail();
        }
    }

    @Test
    public void testGetInitProperties() {
        assertTrue(pulsarOutputSink.getInitProperties() instanceof Properties && pulsarOutputSink.getInitProperties() != null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testOpen_PublickeyNull() {

        try {
            final Class pulsarOutputSinkclass = Class.forName("com.sqlstream.aspen.namespace.pulsar.PulsarOutputSink");
            Field messageEncryption = pulsarOutputSinkclass.getDeclaredField("messageEncryption");
            Field producerval = pulsarOutputSinkclass.getDeclaredField("producer");
            producerval.setAccessible(true);
            producerval.set(pulsarOutputSink, null);
            messageEncryption.setAccessible(true);
            messageEncryption.set(pulsarOutputSink, true);
            pulsarOutputSink.open();
        } catch (IllegalArgumentException ex) {
            throw ex;
        } catch (Exception exep) {
        }

    }

    @Test
    public void testOpen_PublickeyNotNull_messageRoutingMode() {

        try {
            final Class pulsarOutputSinkclass = Class.forName("com.sqlstream.aspen.namespace.pulsar.PulsarOutputSink");
            Field messageEncryption = pulsarOutputSinkclass.getDeclaredField("messageEncryption");
            Field producerval = pulsarOutputSinkclass.getDeclaredField("producer");
            Field publicKeyFile = pulsarOutputSinkclass.getDeclaredField("publicKeyFile");
            Field configProducer = pulsarOutputSinkclass.getDeclaredField("configProducer");

            configProducer.setAccessible(true);
            configProducer.set(pulsarOutputSink, new HashMap<String, String>() {{
                put("messageRoutingMode", CUSTOM_PARTITION);
            }});

            publicKeyFile.setAccessible(true);
            publicKeyFile.set(pulsarOutputSink, "publickey");

            producerval.setAccessible(true);
            producerval.set(pulsarOutputSink, null);

            messageEncryption.setAccessible(true);
            messageEncryption.set(pulsarOutputSink, true);

            pulsarOutputSink.open();
        } catch (IllegalArgumentException ex) {
            throw ex;
        } catch (Exception exep) {
        }

    }


    @Test
    public void testWrite_keyBytesNotNull() {
        try {

            final Class pulsarOutputSinkclass = Class.forName("com.sqlstream.aspen.namespace.pulsar.PulsarOutputSink");
            Field keyColumnIndex = pulsarOutputSinkclass.getDeclaredField("keyColumnIndex");
            Field eventTimeColumnIndex = pulsarOutputSinkclass.getDeclaredField("partitionColumnIndex");
            eventTimeColumnIndex.setAccessible(true);
            eventTimeColumnIndex.set(pulsarOutputSink, 1);

            keyColumnIndex.setAccessible(true);
            keyColumnIndex.set(pulsarOutputSink, 1);

            when(producer.newMessage()).thenReturn(newMessageBuilder);
            when(newMessageBuilder.value(anyString())).thenReturn(newMessageBuilder);
            when(newMessageBuilder.keyBytes(new byte[1])).thenReturn(newMessageBuilder);
            when(newMessageBuilder.eventTime(anyLong())).thenReturn(newMessageBuilder);
            when(newMessageBuilder.sendAsync()).thenReturn(completableFuture);


            when(context.getResultSet()).thenReturn(resultSet);
            when(resultSet.getBytes(anyInt())).thenReturn(new byte[1]);


            String msg = "Test message with write method with sendAsync=";
            byte[] message = msg.getBytes();
            pulsarOutputSink.write(message, 0, message.length);

        } catch (Exception ex) {
            fail();
        }
    }

    @Test
    public void testWrite_WithoutsendAssync() {
        try {
            pulsarOutputSink.writeBounds(1l);
            String msg = "Test message with write method with sendAsync=";

            when(producer.newMessage()).thenReturn(newMessageBuilder);
            when(newMessageBuilder.value(anyString())).thenReturn(newMessageBuilder);
            when(newMessageBuilder.eventTime(anyLong())).thenReturn(newMessageBuilder);
            when(newMessageBuilder.send()).thenReturn(messageId);
            when(context.getResultSet()).thenReturn(resultSet);

            byte[] message = msg.getBytes();

            final Class pulsarOutputSinkclass = Class.forName("com.sqlstream.aspen.namespace.pulsar.PulsarOutputSink");
            Field asyncSend = pulsarOutputSinkclass.getDeclaredField("asyncSend");
            asyncSend.setAccessible(true);
            asyncSend.set(pulsarOutputSink, false);

            for (int i = 0; i < 10; i++)
                pulsarOutputSink.write(message, 0, message.length);

            assertEquals(10, PulsarOutputSink.getCount().get());

        } catch (Exception e) {
            fail("Write Sync failed: " + e.toString());
        }

    }

    @Test
    public void testWrite_WithsendAssync() {
        try {
            pulsarOutputSink.writeBounds(1l);
            String msg = "Test message with write method with sendAsync";

            // Setting values for private variables using reflection
            Class pulsarOutputSinkclass = Class.forName("com.sqlstream.aspen.namespace.pulsar.PulsarOutputSink");
            Field configClient = pulsarOutputSinkclass.getDeclaredField("configClient");
            Field configProducer = pulsarOutputSinkclass.getDeclaredField("configProducer");
            Field producerval = pulsarOutputSinkclass.getDeclaredField("producer");
            configClient.setAccessible(true);
            configProducer.setAccessible(true);
            producerval.setAccessible(true);
            configClient.set(pulsarOutputSink, new HashMap<>());
            configProducer.set(pulsarOutputSink, new HashMap<String, String>() {{
                put("messageRoutingMode", CUSTOM_PARTITION);
            }});

            when(producer.newMessage()).thenReturn(newMessageBuilder);
            when(newMessageBuilder.value(anyString())).thenReturn(newMessageBuilder);
            when(newMessageBuilder.eventTime(anyLong())).thenReturn(newMessageBuilder);
            when(newMessageBuilder.sendAsync()).thenReturn(completableFuture);

            when(resultSet.getMetaData()).thenReturn(resultSetMetaData);
            when(resultSetMetaData.getColumnType(anyInt())).thenReturn(1);


            byte[] message = msg.getBytes();
            pulsarOutputSink.write(message, 0, message.length);

            producerval.set(pulsarOutputSink,null);
            pulsarOutputSink.open();

            producerval.set(pulsarOutputSink,producer);
            pulsarOutputSink.write(message, 0, message.length-3);

        } catch (Exception e) {
            fail("Write failed: " + e.toString());
        }
    }
}

