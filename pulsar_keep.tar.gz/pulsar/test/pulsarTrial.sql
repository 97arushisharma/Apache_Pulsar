CREATE OR REPLACE SCHEMA UTILS;
SET SCHEMA 'UTILS';
SET PATH 'UTILS';
CREATE OR REPLACE SCHEMA "pulsar_test";
ALTER PUMP "pulsar_test".* STOP;
DROP SCHEMA "pulsar_test" CASCADE;
CREATE OR REPLACE SCHEMA "pulsar_test";

----------------------
-- Create PULSAR SINK
----------------------
CREATE OR REPLACE JAR sys_boot.sys_boot.pulsar LIBRARY 'file:plugin/pulsar/pulsar.jar' OPTIONS(0);
alter system add catalog jar sys_boot.sys_boot.pulsar;
CREATE OR REPLACE SERVER PULSAR_SERVER type 'PULSAR' foreign data wrapper ECDA;


-- http input foreign stream
CREATE OR REPLACE FOREIGN STREAM "pulsar_test"."http_input_fs"
(
    "sn_start_time" BIGINT,
    "sn_end_time" BIGINT,
    "radius_calling_station_id" VARCHAR(16),
    "transaction_uplink_bytes" BIGINT,
    "transaction_downlink_bytes" BIGINT,
    "ip_subscriber_ip_address" VARCHAR(40),
    "ip_server_ip_address" VARCHAR(40),
    "http_host" VARCHAR(128),
    "http_content_type" VARCHAR(128),
    "http_url" VARCHAR(128),
    "bearer_3gpp_rat_type" INTEGER,
    "radius_called_station_id" VARCHAR(16),
    "bearer_3gpp_imei" VARCHAR(64),
    "http_reply_code" VARCHAR(64),
    "http_referer" VARCHAR(4),
    "radius_username" VARCHAR(16),
    "http_user_agent" VARCHAR(1024),
    "tcp_os_signature" VARCHAR(32),
    "tcp_v6_os_signature" VARCHAR(32),
    "http_content_type_1" VARCHAR(4),
    "http_host_1" VARCHAR(4),
    "http_url_1" VARCHAR(4),
    "http_url_2" VARCHAR(4),
    "http_url_3" VARCHAR(4),
    "http_user_agent_1" VARCHAR(4),
    "ip_server_ip_address_1" VARCHAR(4),
    "tcp_v6_os_signature_1" VARCHAR(4),
    "ip_subscriber_ip_address_1" VARCHAR(4),
    "bearer_3gpp_rat_type_1" INTEGER,
    "bearer_3gpp_imei_1" VARCHAR(4),
    "ip_server_ip_address_2" VARCHAR(4),
    "ip_protocol" VARCHAR(8),
    "ip_protocol_1" VARCHAR(4),
    "bearer_3gpp_imsi" BIGINT,
    "bearer_3gpp_user_location_information" VARCHAR(32),
    "bearer_3gpp_sgsn_address" VARCHAR(16),
    "bearer_3gpp_sgsn_address_1" VARCHAR(4),
    "tethered_dns" INTEGER,
    "SourceName" VARCHAR(16),
    "PULSAR_PARTITION" INTEGER,
    "PULSAR_KEY" VARBINARY
)
SERVER "FILE_SERVER"
OPTIONS (
    "PARSER" 'CSV',
    "CHARACTER_ENCODING" 'UTF-8',
    "QUOTE_CHARACTER" '"',
    "SEPARATOR" '^',
--    "SKIP_HEADER" 'true',
    "DIRECTORY" '/home/sqlstream/Downloads/',
    "FILENAME_PATTERN" 'data.csv'
);


CREATE OR REPLACE VIEW "pulsar_test"."http_out_1" AS
SELECT STREAM * , TO_TIMESTAMP(("sn_end_time") * 1000) AS PULSAR_TIMESTAMP
FROM "pulsar_test"."http_input_fs";

----------
-- pipeline_1 1: Route to PULSAR
----------
CREATE OR REPLACE FOREIGN STREAM "pulsar_test"."http_out_fs"
(
    "sn_start_time" BIGINT,
    "sn_end_time" BIGINT,
    "radius_calling_station_id" VARCHAR(16),
    "transaction_uplink_bytes" BIGINT,
    "transaction_downlink_bytes" BIGINT,
    "ip_subscriber_ip_address" VARCHAR(16),
    "ip_server_ip_address" VARCHAR(16),
    "http_host" VARCHAR(128),
    "http_content_type" VARCHAR(128),
    "http_url" VARCHAR(128),
    "bearer_3gpp_rat_type" INTEGER,
    "radius_called_station_id" VARCHAR(16),
    "bearer_3gpp_imei" VARCHAR(64),
    "http_reply_code" VARCHAR(64),
    "http_referer" VARCHAR(4),
    "radius_username" VARCHAR(4),
    "http_user_agent" VARCHAR(1024),
    "tcp_os_signature" VARCHAR(32),
    "tcp_v6_os_signature" VARCHAR(32),
    "http_content_type_1" VARCHAR(4),
    "http_host_1" VARCHAR(4),
    "http_url_1" VARCHAR(4),
    "http_url_2" VARCHAR(4),
    "http_url_3" VARCHAR(4),
    "http_user_agent_1" VARCHAR(4),
    "ip_server_ip_address_1" VARCHAR(4),
    "tcp_v6_os_signature_1" VARCHAR(4),
    "ip_subscriber_ip_address_1" VARCHAR(4),
    "bearer_3gpp_rat_type_1" INTEGER,
    "bearer_3gpp_imei_1" VARCHAR(4),
    "ip_server_ip_address_2" VARCHAR(4),
    "ip_protocol" VARCHAR(4),
    "ip_protocol_1" VARCHAR(4),
    "bearer_3gpp_imsi" BIGINT,
    "bearer_3gpp_user_location_information" VARCHAR(32),
    "bearer_3gpp_sgsn_address" VARCHAR(16),
    "bearer_3gpp_sgsn_address_1" VARCHAR(4),
    "tethered_dns" INTEGER,
    "SourceName" VARCHAR(8),
    "PULSAR_PARTITION" INTEGER,
    "PULSAR_KEY" VARBINARY,
    "PULSAR_TIMESTAMP" TIMESTAMP
)
SERVER "PULSAR_SERVER"
OPTIONS (
    "FORMATTER" 'CSV',
--    "AVRO_SCHEMA_LOCATION" '/home/sqlstream/Downloads/edrhttp.avsc',
    "COUNT_SCHEDULER_TIME" '5000', -- Milli seconds. Set 0 to disable.
    "CHARACTER_ENCODING" 'UTF-8',
--    "FORMATTER_INCLUDE_ROWTIME" 'true',
    "PULSAR_CONFIG_FILE" '/home/sqlstream/Downloads/pulsar.properties'
);
CREATE OR REPLACE PUMP "pulsar_test"."http_out_fs_pump" STOPPED AS
INSERT INTO "pulsar_test"."http_out_fs" 
SELECT STREAM * FROM "pulsar_test"."http_out_1";

ALTER PUMP "pulsar_test".* START;
SELECT STREAM * FROM "pulsar_test"."http_out_1";
